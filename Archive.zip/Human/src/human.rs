struct human{

	id : i32;
	name : string;
}
