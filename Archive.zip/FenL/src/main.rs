extern crate rand;

use std::io;
use rand::Rng;
use std::cmp::Ordering;

fn main()
{
loop{
	let secret_number = rand::thread_rng().gen_range(1,101);

	println!("The secret number is {}",secret_number);

	println!("Please input your guess.");

	let mut number = String::new();

	io::stdin().read_line(&mut number).ok().expect("failed to read line");

	println!("You guessed: {}",number);

	let number: u32 =match number.trim().parse()
	{
		Ok(num)=>num,
		Err(_)=>
		{
			println!("NOT A NUMBER.");
			continue;
		},
		
	};
	
	match number.cmp(&secret_number){
		Ordering::Less=>println!("Too small."),
		Ordering::Greater=>println!("Too greater."),
		Ordering::Equal=>
		{
			println!("You're right.");
			break;
		}
	}
	}
}
