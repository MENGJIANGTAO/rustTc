use std::thread;
use std::sync::{Arc,Mutex};

fn main() {
	let mut range = 0..10;
	loop{
		match range.next(){
			Some(x)=>{
				println!("{}",x);
			},
			None=>{break}
		}
	}
	
	let nums = vec![1,2,3,4,5,6,7];
	for num in &nums{
		println!("{}",num);
	}
	let one_to_one_hundred = (1..101).collect::<Vec<_>>();
	
	let greater_than_forty_two = (0..100).find(|x| * x > 42);

	match greater_than_forty_two {
		Some(_) => println!("We got some numbers!"),
		None=> println!("No number found"),
	}
	for i in(1..100).filter(|&x| x %2 ==  0){
		print!("{} ",i);
	}	
	println!("Su shu");
	for j in (1..1000).filter(|&x| x % 1 == 0)
		.filter(|&x| x % 3 == 0)
		.take(100)
		.collect::<Vec<_>>(){
		print!("{} ",j);
	}
	let handle = thread::spawn(||{
		println!("Hello from a thread!");
		});
	handle.join().unwrap();
	let data = Arc::new(Mutex::new(vec![1,2,3]));
	for i in 0..3{
		let data = data.clone();
		thread::spawn(move||{
			let mut data = data.lock().unwrap();
			data[i]+=1;
		});
	}
	thread::sleep_ms(50);

}
