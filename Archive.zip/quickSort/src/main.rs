
pub fn quickSort(object:Vec<i32>,left:i32,right:i32){
	if(left < right){
		let i = left;
		let j = right;
		let temp = object[left];

		while(i<j && object[j]>=temp){
			j-= 1;
		}
		if(i<j){
			i+=1;
			object[i] = object[j];
		}


		while(i<j && object[i]<temp){
			i+=1;
		}

		if(i<j){
			j-=1;
			object[j] = object[i];
		}

		object[i] = temp;
		quickSort(object,left,i-1);
		quickSort(object,i+1,right);
	}
	
}
fn main() {
    println!("Hello, world!");
}
