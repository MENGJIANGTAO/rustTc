fn main(){
	let string = "Hello there.";
	let mut hello = "Hello".to_string(); // mut s:String
	println!("{}",hello);

	println!("After push_str");

	hello.push_str(",world.");
	println!("{}",hello);

	let name = "mengjiangtao.".to_string();
	takes_slice(&name);
	
	let hachiko = "忠犬ハチ公";
	println!("print as bytes");
	for bbyte in hachiko.as_bytes(){
		println!("{}",bbyte);
	}
	println!("print as char");
	for bchar in hachiko.chars(){
		println!("{}",bchar);
	}
	
}
fn takes_slice(slice:&str){
	println!("Got:{}",slice);
}
