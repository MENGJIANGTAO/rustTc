fn main(){
	let v = vec![1,2,3];
	let v1 = vec![0;10]; // ten zeroes
	let v2 = vec![1,2,3,4,5];
	println!("The third element of v2 is {}",v[2]);
	let mut v3 = vec![1,2,3,4,5];
	for i in &v2{
		println!("A reference to {}",i);
	}

	for j in &mut v3{
		println!("A mutable reference to {}",j);
	}

	for k in v3{
		println!("Take ownership of the vector and its element {}",k);
	}
}
