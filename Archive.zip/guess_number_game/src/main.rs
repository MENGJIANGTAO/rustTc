extern crate rand;
use std::cmp::Ordering;
use std::io;
use rand::Rng;
fn main() {
//	loop{
    		let secret_number = rand::thread_rng().gen_range(1,101);
    		println!("The random number is {}",secret_number);
    		println!("Guessing a number~~~");
    		println!("please input a number-->");
	loop{
    		let mut number = String::new();
    		io::stdin().read_line(&mut number).ok().expect("Wrong number");
    		let number: u32 =match number.trim().parse()
		{
			Ok(num)=>num,
			Err(_) =>
			{
				println!("Please input a number:");
				continue;
			}, 
		};
   		println!("your guessed:{}",number);
    		match number.cmp(&secret_number){
      			Ordering::Less =>println!("Too small."),
      			Ordering::Greater =>println!("Too big."),
      			Ordering::Equal =>{
				println!("You got it.");
				break;
			},

    		}
	}
}
